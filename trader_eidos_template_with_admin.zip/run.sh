#!/usr/bin/env bash
python -m app.trade
