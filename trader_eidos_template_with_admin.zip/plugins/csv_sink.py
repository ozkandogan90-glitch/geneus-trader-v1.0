
# plugins/csv_sink.py — Looker/BI friendly flat CSV export
from plugins.runtime import register
import os
@register("after_results")
def csv_sink(df_trades=None, settings=None, **_):
    if df_trades is None or len(df_trades)==0:
        print("[csv_sink] Yazılacak veri yok."); return
    os.makedirs("exports", exist_ok=True)
    path = os.path.join("exports", "trades_flat.csv")
    try:
        df_trades.to_csv(path, index=False)
        print(f"[csv_sink] ✅ CSV yazıldı: {path}")
    except Exception as e:
        print(f"[csv_sink] ⚠️  CSV hatası: {e}")
