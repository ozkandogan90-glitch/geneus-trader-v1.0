
# plugins/bq_sink.py
from __future__ import annotations
from plugins.runtime import register
import pandas as pd

@register("after_results")
def write_bq(df_trades: pd.DataFrame | None = None, settings=None, **_):
    if df_trades is None or len(df_trades)==0:
        print("[bq_sink] Yazılacak satır yok."); return

    try:
        from pandas_gbq import to_gbq
    except Exception as e:
        print(f"[bq_sink] pandas_gbq yok: {e}"); return

    cfg = getattr(settings, "bigquery", None)
    if cfg is None:
        print("[bq_sink] bigquery config yok."); return

    project = getattr(cfg, "project_id", None)
    dataset = getattr(cfg, "dataset", None)
    table   = getattr(cfg, "table", None)
    loc     = getattr(cfg, "location", "EU")

    if not all([project, dataset, table]):
        print("[bq_sink] Eksik config: project/dataset/table"); return

    try:
        to_gbq(df_trades.copy(), f"{dataset}.{table}",
               project_id=project, if_exists="append",
               api_method="load_csv", progress_bar=False, location=loc)
        print(f"[bq_sink] ✅ Append OK → {project}.{dataset}.{table} (+{len(df_trades)} satır)")
    except Exception as e:
        print(f"[bq_sink] ⚠️  Yazım hatası: {e}")
