
# plugins/excel_export.py
from __future__ import annotations
from plugins.runtime import register
from datetime import datetime
import os
import pandas as pd

@register("after_results")
def save_excel(df_trades=None, settings=None, **_):
    if df_trades is None or len(df_trades)==0:
        print("[excel_export] Yazılacak satır yok."); return
    cfg = getattr(settings, "excel_export", None)
    out_dir = getattr(cfg, "dir", "exports") if cfg else "exports"
    prefix  = getattr(cfg, "prefix", "trade_logs_") if cfg else "trade_logs_"
    os.makedirs(out_dir, exist_ok=True)
    fname = f"{prefix}{datetime.now().strftime('%Y%m%d_%H%M%S')}.xlsx"
    path = os.path.join(out_dir, fname)
    try:
        df_trades.to_excel(path, index=False)
        print(f"[excel_export] ✅ Kaydedildi: {path}")
    except Exception as e:
        print(f"[excel_export] ⚠️  Excel hatası: {e}")
