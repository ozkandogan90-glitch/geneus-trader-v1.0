
# plugins/runtime.py
# Minimal plugin runtime — dependency‑free

import pkgutil, importlib, traceback

_REGISTRY = {}  # {"hook_name": [fn, ...]}

def register(hook_name: str):
    """Decorator to register a function to a named hook."""
    def deco(fn):
        _REGISTRY.setdefault(hook_name, []).append(fn)
        return fn
    return deco

def run(hook_name: str, **kwargs):
    """Run all plugin functions registered to a hook, protecting the host app."""
    for fn in _REGISTRY.get(hook_name, []):
        try:
            fn(**kwargs)
        except Exception as e:
            print(f"[PLUGIN:{fn.__module__}] {e}")
            traceback.print_exc()

def load_plugins(enabled: list[str] | None = None):
    """Import all modules in the 'plugins' package (optionally filtered)."""
    try:
        import plugins  # ensure package exists
    except Exception:
        return

    for m in pkgutil.iter_modules(plugins.__path__):
        if enabled and m.name not in enabled:
            continue
        importlib.import_module(f"plugins.{m.name}")
