
# plugins/email_alert.py (placeholder)
from plugins.runtime import register
@register("after_results")
def email_summary(df_trades=None, settings=None, **_):
    if df_trades is None or len(df_trades)==0:
        return
    try:
        win_rate = float((df_trades["pnl_pct"]>0).mean()*100.0)
    except Exception:
        win_rate = 0.0
    print(f"[email_alert] (örnek) Gün özeti: {len(df_trades)} işlem, kazanma oranı %{win_rate:.1f}")
