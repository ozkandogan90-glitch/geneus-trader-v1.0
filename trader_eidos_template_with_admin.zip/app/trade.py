
# app/trade.py — Demo host to show hooks
from __future__ import annotations
import os, yaml, types, pandas as pd
from plugins.runtime import load_plugins, run as run_hook

# <llm:imports>
# LLM gerektiğinde yeni importları buraya ekleyebilir.
# </llm:imports>

def load_settings(path: str = "config.yaml"):
    with open(path, "r", encoding="utf-8") as f:
        data = yaml.safe_load(f)
    return types.SimpleNamespace(**data)

def demo_results_df() -> pd.DataFrame:
    rows = [
        dict(ticker="AAPL", combination="Bullish Engulfing - 1D",
             pattern_name="Bullish Engulfing", direction="bullish",
             entry_date="2024-10-01", entry_price=100.0, exit_date="2024-10-05",
             exit_price=112.0, pnl_pct=0.12, hit_tp50=True,
             max_runup_pct=0.15, max_drawdown_pct=-0.03,
             ulke="Amerika", borsa_kategori="S&P 100", zaman_dilimi="1D",
             sl_yuzde=7.0, tp_yuzde=15.0, tp_kismi_yuzde=50, hacim_lb=4, hacim_artis_yuzde=49,
             sektor="IT", trend="Up", atr_yuzde=0.02, risk_odul=2.14),
        dict(ticker="MSFT", combination="Bearish Engulfing - 1D",
             pattern_name="Bearish Engulfing", direction="bearish",
             entry_date="2024-10-10", entry_price=100.0, exit_date="2024-10-12",
             exit_price=96.0, pnl_pct=0.04, hit_tp50=False,
             max_runup_pct=0.06, max_drawdown_pct=-0.02,
             ulke="Amerika", borsa_kategori="S&P 100", zaman_dilimi="1D",
             sl_yuzde=7.0, tp_yuzde=15.0, tp_kismi_yuzde=50, hacim_lb=4, hacim_artis_yuzde=49,
             sektor="IT", trend="Side", atr_yuzde=0.018, risk_odul=2.14),
    ]
    return pd.DataFrame(rows)

def main():
    SETTINGS = load_settings()
    load_plugins(getattr(SETTINGS, "plugins", []))

    # --- pre-run hooks ---
    run_hook("before_run", params=dict(mode="demo"))

    df_trades = demo_results_df()

    # <llm:after_results>
    # LLM burada df_trades üzerinde hafif işlemler yapabilir (örn. yeni sütun).
    # </llm:after_results>

    # --- results hook ---
    run_hook("after_results", df_trades=df_trades, settings=SETTINGS)

    # --- summary hook (optional downstream) ---
    run_hook("on_summary", df=df_trades)

    print("[INFO] after_results tetiklendi.")

if __name__ == "__main__":
    main()
