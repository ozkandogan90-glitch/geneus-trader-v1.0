
# app/summaries.py — Optional summary helpers
from __future__ import annotations
import numpy as np, pandas as pd

def build_summaries(df_trades: pd.DataFrame):
    agg = {
        "pnl_pct":["mean","median","count","sum"],
        "hit_tp50":["mean"],
        "max_runup_pct":["max"],
        "max_drawdown_pct":["min"],
    }
    gb_cols = ["ticker","combination","pattern_name","direction","ulke","borsa_kategori","zaman_dilimi",
               "sl_yuzde","tp_yuzde","tp_kismi_yuzde","hacim_lb","hacim_artis_yuzde","sektor","trend","risk_odul"]
    g = df_trades.groupby(gb_cols).agg(agg)
    g.columns = ["Ort. Getiri","Medyan Getiri","İşlem Sayısı","Toplam Getiri","TP50 Oranı","Maks. Yükseliş","Maks. Düşüş"]
    g = g.reset_index()
    return {"summary": g}
