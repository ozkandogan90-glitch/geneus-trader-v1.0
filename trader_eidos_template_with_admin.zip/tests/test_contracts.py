
import pandas as pd

REQUIRED = {"ticker","combination","pattern_name","direction",
"entry_date","entry_price","exit_date","exit_price",
"pnl_pct","hit_tp50","max_runup_pct","max_drawdown_pct",
"ulke","borsa_kategori","zaman_dilimi","sl_yuzde","tp_yuzde",
"tp_kismi_yuzde","hacim_lb","hacim_artis_yuzde","sektor","trend","atr_yuzde","risk_odul"}

def test_df_contract():
    df = pd.DataFrame([{
        "ticker":"AAPL","combination":"x","pattern_name":"Bullish Engulfing","direction":"bullish",
        "entry_date":"2024-01-01","entry_price":1.0,"exit_date":"2024-01-02","exit_price":1.1,
        "pnl_pct":0.1,"hit_tp50":True,"max_runup_pct":0.11,"max_drawdown_pct":-0.02,
        "ulke":"Amerika","borsa_kategori":"S&P","zaman_dilimi":"1 Gün","sl_yuzde":7.0,"tp_yuzde":15.0,
        "tp_kismi_yuzde":50,"hacim_lb":4,"hacim_artis_yuzde":49,"sektor":"BT","trend":"Up","atr_yuzde":0.02,"risk_odul":2.0
    }])
    assert REQUIRED.issubset(df.columns), "Eksik kolonlar var"
