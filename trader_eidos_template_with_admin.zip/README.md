
# Trader Eidos — Template + Admin (Streamlit)

Bu paket, LLM‑dostu **plugin + config** mimarisi ile birlikte **örnek yönetim aracı** (Streamlit) ve
**HOOKS şeması** içerir.

## Hızlı Başlangıç
```bash
pip install -r requirements.txt
python -m app.trade            # demo çalıştır
streamlit run admin/app_admin.py   # yönetim aracı
```

## Yapı
- `plugins/runtime.py` — minimal çalışma zamanı
- `plugins/*.py` — örnek eklentiler (Excel, BQ, CSV, Telegram)
- `config.yaml` — plugin’ler ve hedef ayarlar
- `app/trade.py` — demo host; <llm:imports> ve <llm:after_results> bölgeleri
- `admin/app_admin.py` — Streamlit yönetim arayüzü
- `docs/HOOKS_SCHEMA.md` — kanca şeması
- `tools/scaffold_plugin.py` — yeni eklenti iskeleti üretir

## Notlar
- BigQuery kullanımı için `pandas-gbq` ve GCP kimlik doğrulaması gerekir.
- Yönetim aracı config’i düzenleyebilir, plugin aç/kapa yapabilir ve demo run başlatır.
