
# tools/scaffold_plugin.py
import sys, os

TEMPLATE = """\
# plugins/{name}.py
from plugins.runtime import register

@register("{hook}")
def {name}(df_trades=None, settings=None, **kwargs):
    # TODO: buraya mantığını ekle
    print("[{name}] çalıştı. Kayıt sayısı:", 0 if df_trades is None else len(df_trades))
"""

def main():
    if len(sys.argv) < 2:
        print("Kullanım: python tools/scaffold_plugin.py <plugin_adı> [hook_adı]")
        sys.exit(1)
    name = sys.argv[1].strip()
    hook = sys.argv[2].strip() if len(sys.argv) > 2 else "after_results"
    path = os.path.join(os.path.dirname(__file__), "..", "plugins", f"{name}.py")
    os.makedirs(os.path.dirname(path), exist_ok=True)
    with open(path, "w", encoding="utf-8") as f:
        f.write(TEMPLATE.format(name=name, hook=hook))
    print("Oluşturuldu:", path)

if __name__ == "__main__":
    main()
