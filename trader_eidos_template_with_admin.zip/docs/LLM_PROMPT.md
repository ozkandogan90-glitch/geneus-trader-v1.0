
# LLM_PROMPT.md — Kısa Talimat
Bu projede eklentiler `plugins/` altında, kancalar `plugins.runtime.register` ile tanımlı.
Sadece yeni bir dosya oluştur: `plugins/<ad>.py`.
`@register("after_results")` ile bağlan.
`df_trades` DataFrame’ini değiştirme, sadece oku.
Yeni bağımlılık ekleme; gerekirse try/except ile opsiyonel yap.
Bana yalnızca o tek dosyanın içeriğini ver; başka dosyalara dokunma.
