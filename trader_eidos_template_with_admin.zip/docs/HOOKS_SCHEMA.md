
# HOOKS_SCHEMA — Trader Eidos Plugin Kancaları (Örnek Şema)

Bu dosya, projede önerilen kanca (hook) adlarını ve bu kancaların tipik kullanım alanlarını özetler.

## 1) Veri İndirme / Ön‑İşleme
- `before_download` — İndirme öncesi param kontrolü/guard.
- `after_download` — Ham veri alındıktan sonra (temizleme, normalizasyon).
- `after_resample` — Resample/yeniden örnekleme sonrası.

## 2) Formasyon / Pattern Kütüphanesi
- `register_pattern` — Yeni pattern fonksiyonları ekleme.
- `patterns_loaded` — Pattern listesi finalize edildiğinde.

## 3) Hacim / Özel Sinyal Filtreleri
- `signal_filter` — Hacim/volatilite / haber filtreleri uygulama.

## 4) Strateji Jenerasyonu (Sabit Kombinasyonlar)
- `register_strategy` — Sabit strateji/preset enjekte etme.

## 5) Backtest Motoru
- `before_simulation` — Simülasyon öncesi.
- `on_trade_entry` — İşlem açıldığında.
- `on_trade_exit` — İşlem kapandığında.
- `after_simulation` — Toplu sonuçlar üretildiğinde.

## 6) Özet / Raporlama
- `on_summary` — Özet DataFrame/rapor üretimi aşamasında.
- `summary_mutators` — Son özet tablolarına hafif dokunuşlar.

## 7) Sonuçların Gösterimi ve Dışa Aktarım
- `after_results` — Nihai sonuç DataFrame’i hazır olduğunda (Excel/BQ/CSV/PDF sink vb.).
- `results_sink` — Alternatif hedef yazımları (Snowflake/Sheets vs.)

## 8) UI / Koşu Başlatma
- `before_run` — Koşu öncesi doğrulamalar.
- `on_ui_action` — UI tarafındaki özel buton/olay tetikleyicileri.

## 9) Hata ve Durdurma
- `on_error` — Hata durumlarında.
- `on_stop` — Kullanıcı/iş akışı durdurma sinyali.

## 10) Zenginleştirme / Metadata
- `enrich_trade_record` — Tekil trade log satırına ek alanlar ekleme (ülke/sektör/risk sınıfı vb.).
