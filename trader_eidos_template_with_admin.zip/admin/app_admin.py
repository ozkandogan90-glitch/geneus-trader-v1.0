
# admin/app_admin.py — Streamlit management UI
import os, yaml, types, subprocess, sys, time
import streamlit as st
from pathlib import Path

CONFIG_PATH = Path("config.yaml")

def load_settings(path: Path = CONFIG_PATH):
    with open(path, "r", encoding="utf-8") as f:
        data = yaml.safe_load(f)
    return types.SimpleNamespace(**data)

def save_settings(ns, path: Path = CONFIG_PATH):
    # Convert SimpleNamespace back to dict
    def to_dict(x):
        if isinstance(x, types.SimpleNamespace):
            return {k: to_dict(getattr(x, k)) for k in vars(x)}
        if isinstance(x, dict):
            return {k: to_dict(v) for k, v in x.items()}
        return x
    with open(path, "w", encoding="utf-8") as f:
        yaml.safe_dump(to_dict(ns), f, allow_unicode=True, sort_keys=False)

def discover_plugins():
    plugins_dir = Path("plugins")
    items = []
    if plugins_dir.exists():
        for p in plugins_dir.glob("*.py"):
            if p.name == "__init__.py":
                continue
            items.append(p.stem)
    return sorted(items)

st.set_page_config(page_title="Trader Eidos — Admin", layout="wide")
st.title("🧰 Trader Eidos — Yönetim Paneli")

tab_runs, tab_plugins, tab_configs, tab_outputs, tab_schedules, tab_system = st.tabs(
    ["Runs", "Plugins", "Configs", "Outputs", "Schedules", "System"]
)

with tab_plugins:
    st.subheader("🔌 Plugin Yönetimi")
    settings = load_settings()
    enabled = list(getattr(settings, "plugins", []))
    found = discover_plugins()

    cols = st.columns(3)
    with cols[0]:
        st.write("**Bulunan Pluginler**")
        st.code("\n".join(found) or "(yok)")
    with cols[1]:
        st.write("**Aktif Pluginler**")
        current = st.multiselect("Açık olanlar", found, default=enabled, key="plugins_enabled_ui")
        if st.button("💾 Kaydet (config.yaml)"):
            settings.plugins = current
            save_settings(settings)
            st.success("Kaydedildi.")
    with cols[2]:
        st.write("**Yeni Plugin İskeleti**")
        new_name = st.text_input("Plugin adı", value="my_plugin")
        if st.button("➕ İskelet oluştur"):
            path = Path("plugins") / f"{new_name}.py"
            if path.exists():
                st.warning("Zaten var.")
            else:
                path.write_text(f"""# plugins/{new_name}.py\nfrom plugins.runtime import register\n\n@register("after_results")\ndef {new_name}(df_trades=None, settings=None, **kwargs):\n    print("[{new_name}] çalıştı. Kayıt sayısı:", 0 if df_trades is None else len(df_trades))\n""", encoding="utf-8")
                st.success(f"Oluşturuldu: {path}")

with tab_configs:
    st.subheader("⚙️ Config Yönetimi")
    st.caption("config.yaml üzerinde hızlı düzenleme")
    txt = Path("config.yaml").read_text(encoding="utf-8")
    new_txt = st.text_area("config.yaml", value=txt, height=380)
    if st.button("💾 config.yaml Kaydet"):
        Path("config.yaml").write_text(new_txt, encoding="utf-8")
        st.success("config.yaml güncellendi.")

    st.divider()
    st.write("Örnek profiller:")
    if Path("configs/config.bist.yaml").exists():
        if st.button("⬇️ config.bist.yaml'ı yükle"):
            Path("config.yaml").write_text(Path("configs/config.bist.yaml").read_text(encoding="utf-8"), encoding="utf-8")
            st.success("Yüklendi.")
    if Path("configs/config.us.yaml").exists():
        if st.button("⬇️ config.us.yaml'ı yükle"):
            Path("config.yaml").write_text(Path("configs/config.us.yaml").read_text(encoding="utf-8"), encoding="utf-8")
            st.success("Yüklendi.")

with tab_runs:
    st.subheader("🏃 Çalıştırma")
    st.caption("Basit demo: `python -m app.trade` komutu")
    if st.button("▶️ Demo Run (app.trade)"):
        try:
            # Not: Bazı ortamlarda Streamlit içinde subprocess göstermeyebilir; bu yüzden kısa çıktı yazıyoruz.
            proc = subprocess.run([sys.executable, "-m", "app.trade"], capture_output=True, text=True, timeout=120)
            st.code(proc.stdout or "(stdout boş)")
            if proc.stderr:
                with st.expander("stderr"):
                    st.code(proc.stderr)
            st.success("Demo tamamlandı.")
        except Exception as e:
            st.error(f"Hata: {e}")

with tab_outputs:
    st.subheader("📦 Çıktılar")
    out_dir = Path("exports")
    out_dir.mkdir(exist_ok=True)
    files = sorted(out_dir.glob("*"))
    if files:
        for f in files[-10:]:
            st.write(f"• {f.name} ({f.stat().st_size} bytes)")
    else:
        st.info("Henüz çıktı yok. Demo run sonrası burada listelenecek.")

with tab_schedules:
    st.subheader("⏱️ Zamanlama (örnek/placeholder)")
    st.write("Bu sayfa ileride cron/apscheduler entegrasyonu için yer tutucu.")

with tab_system:
    st.subheader("🛠️ Sistem")
    st.write("`docs/HOOKS_SCHEMA.md` içindeki hook şemasına göz atın.")
    if Path("docs/HOOKS_SCHEMA.md").exists():
        st.code(Path("docs/HOOKS_SCHEMA.md").read_text(encoding="utf-8"))
