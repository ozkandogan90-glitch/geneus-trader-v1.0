# Admin (Yönetim Paneli)
Streamlit tabanlı basit bir yönetim aracı.

## Çalıştırma
```bash
pip install -r requirements.txt
streamlit run admin/app_admin.py
```
